
export const extractTextFromFile = async (file: File): Promise<string> => {
  const fileType = file.type;
  const fileName = file.name.toLowerCase();

  try {
    if (fileType === 'application/pdf' || fileName.endsWith('.pdf')) {
      return await extractTextFromPDF(file);
    } else if (
      fileType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || 
      fileName.endsWith('.docx')
    ) {
      return await extractTextFromDocx(file);
    } else if (fileType === 'text/plain' || fileName.endsWith('.txt')) {
      return await extractTextFromTxt(file);
    } else {
      throw new Error("Format fail tidak disokong. Sila guna PDF (.pdf), Word (.docx), atau Text (.txt).");
    }
  } catch (error: any) {
    console.error("Error extracting text:", error);
    throw new Error(error.message || "Gagal membaca fail. Pastikan fail tidak rosak dan format betul.");
  }
};

const extractTextFromTxt = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => resolve(event.target?.result as string || '');
    reader.onerror = (error) => reject(error);
    reader.readAsText(file);
  });
};

const extractTextFromPDF = async (file: File): Promise<string> => {
  // Dynamic import to avoid initial load crash
  // We use type assertion to handle dynamic module import in this environment
  const pdfjsLib = await import('pdfjs-dist');
  
  // Set worker
  // Note: We use the specific worker build matching the version
  if (pdfjsLib.GlobalWorkerOptions) {
      pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://esm.sh/pdfjs-dist@3.11.174/build/pdf.worker.min.mjs';
  }

  const arrayBuffer = await file.arrayBuffer();
  
  // Load the PDF document
  const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
  const pdf = await loadingTask.promise;
  let fullText = '';

  // Iterate through each page
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const textContent = await page.getTextContent();
    
    // Extract strings from text items
    const pageText = textContent.items
      .map((item: any) => item.str)
      .join(' ');
      
    fullText += `--- Halaman ${i} ---\n${pageText}\n\n`;
  }
  return fullText;
};

const extractTextFromDocx = async (file: File): Promise<string> => {
  // Dynamic import
  const mammoth = await import('mammoth');
  
  const arrayBuffer = await file.arrayBuffer();
  const result = await mammoth.extractRawText({ arrayBuffer });
  return result.value;
};
