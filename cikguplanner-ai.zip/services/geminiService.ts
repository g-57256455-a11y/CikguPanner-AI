import { GoogleGenAI, Type, Schema } from "@google/genai";
import { WeeklyPlanItem, DailyRPHRequest } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// System instruction for the persona
const SYSTEM_INSTRUCTION = `
Anda adalah seorang Guru Cemerlang di Malaysia yang pakar dalam penyediaan Rancangan Pengajaran Tahunan (RPT) dan Rancangan Pengajaran Harian (RPH) mengikut format standard Kementerian Pendidikan Malaysia (KPM). 
Anda teliti, kreatif, dan mematuhi standard PAK-21 (Pembelajaran Abad Ke-21).
`;

export const analyzeRPT = async (rptRawText: string): Promise<WeeklyPlanItem[]> => {
  const modelId = "gemini-2.5-flash"; // Good for large context analysis

  const schema: Schema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        minggu: { type: Type.INTEGER, description: "Nombor minggu (contoh: 1)" },
        tema: { type: Type.STRING, description: "Tema pembelajaran utama" },
        topik: { type: Type.STRING, description: "Topik umum atau tajuk utama" },
        bidangList: { 
          type: Type.ARRAY, 
          items: { type: Type.STRING }, 
          description: "Senarai bidang atau pecahan sub-topik yang wujud dalam minggu ini. Contoh untuk Agama Islam: ['Al-Quran', 'Hadis', 'Jawi', 'Ulum', 'Tasmik']. Contoh Bahasa: ['Tatabahasa', 'Pemahaman', 'Karangan']." 
        },
        standardKandungan: { type: Type.STRING, description: "Ringkasan Standard Kandungan" },
        standardPembelajaran: { type: Type.STRING, description: "Ringkasan Standard Pembelajaran" },
        catatan: { type: Type.STRING, description: "Catatan tambahan jika ada (contoh: Cuti Sekolah)" }
      },
      required: ["minggu", "tema", "topik", "standardKandungan", "standardPembelajaran"],
      propertyOrdering: ["minggu", "tema", "topik", "bidangList", "standardKandungan", "standardPembelajaran", "catatan"]
    }
  };

  const prompt = `
  Analisa teks RPT (Rancangan Pengajaran Tahunan) mentah yang diberikan di bawah.
  Keluarkan satu senarai berstruktur mengikut minggu.
  
  PENTING:
  Jika dalam satu minggu terdapat pelbagai bidang (contohnya Pendidikan Islam ada Al-Quran, Jawi, Tasmik serentak), sila senaraikan kesemua bidang tersebut dalam 'bidangList'.
  
  TEKS RPT:
  ${rptRawText}
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: schema,
        temperature: 0.2, // Low temperature for factual extraction
      }
    });

    const jsonText = response.text;
    if (!jsonText) return [];
    
    return JSON.parse(jsonText) as WeeklyPlanItem[];
  } catch (error) {
    console.error("Error analyzing RPT:", error);
    throw new Error("Gagal menganalisa RPT. Sila cuba lagi.");
  }
};

export const generateDailyRPH = async (
  rptContext: string, 
  request: DailyRPHRequest
): Promise<string> => {
  const modelId = "gemini-2.5-flash";

  const prompt = `
  Berdasarkan maklumat berikut, sila jana satu Rancangan Pengajaran Harian (RPH) yang lengkap.

  MAKLUMAT KELAS:
  - Hari: ${request.day}
  - Tarikh: ${request.date || 'TIADA'}
  - Kelas: ${request.className}
  - Masa: ${request.time}
  - Minggu: ${request.weekItem.minggu}
  - Tema: ${request.weekItem.tema}
  - Topik Utama: ${request.weekItem.topik}
  ${request.selectedBidang ? `- **FOKUS BIDANG / SUB-TOPIK HARI INI**: ${request.selectedBidang}` : ''}
  - Standard Kandungan (Mingguan): ${request.weekItem.standardKandungan}
  - Standard Pembelajaran (Mingguan): ${request.weekItem.standardPembelajaran}
  ${request.additionalContext ? `- **PERMINTAAN/KONTEKS TAMBAHAN DARI GURU**: "${request.additionalContext}" (Sila pastikan RPH mengambil kira arahan ini)` : ''}

  ARAHAN KHUSUS:
  1. Anda MESTI menjana RPH yang spesifik untuk bidang **${request.selectedBidang || request.weekItem.topik}** sahaja.
  2. Pilih Standard Kandungan & Pembelajaran yang relevan dengan bidang ini sahaja daripada senarai mingguan.
  3. Abaikan bidang lain yang tidak berkaitan dengan fokus hari ini.
  ${request.additionalContext ? `4. **PENTING**: Sila integrasikan konteks tambahan guru (${request.additionalContext}) ke dalam aktiviti atau objektif RPH.` : ''}

  FORMAT RPH YANG DIKEHENDAKI (Gunakan Markdown):
  1. **Maklumat Mata Pelajaran**: (Nyatakan Bidang: ${request.selectedBidang || request.weekItem.topik}) - Tarikh: ${request.date || request.day}
  2. **Objektif Pembelajaran**: (Di akhir PdP, murid dapat...) - Pastikan boleh diukur (SMART).
  3. **Kriteria Kejayaan**: Murid dapat...
  4. **Aktiviti PdP**:
     - Set Induksi (5 minit)
     - Perkembangan (Aktiviti Utama) - Masukkan elemen PAK-21 yang sesuai dengan ${request.selectedBidang || 'topik ini'}.
     - Penutup (Refleksi)
  5. **Bahan Bantu Mengajar (BBM)**
  6. **Elemen Merentas Kurikulum (EMK)**
  7. **Refleksi Guru**: (Ruang kosong untuk guru tulis selepas kelas)
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7, 
      }
    });

    return response.text || "Tiada RPH dijana.";
  } catch (error) {
    console.error("Error generating RPH:", error);
    throw new Error("Gagal menjana RPH Harian.");
  }
};

export const convertToJawi = async (text: string): Promise<string> => {
  const modelId = "gemini-2.5-flash";

  const prompt = `
  Tukarkan teks RPH berikut daripada tulisan Rumi kepada tulisan Jawi yang standard (Za'ba/DBP).
  
  ARAHAN PENTING:
  1. KEKALKAN format Markdown sepenuhnya (Bold, Italic, Tables, Bullet points).
  2. Jangan tukar struktur ayat, hanya tukar sistem tulisan.
  3. Istilah Bahasa Inggeris (seperti "Parking Lot", "Gallery Walk") boleh dikekalkan dalam Rumi jika tiada padanan Jawi yang umum, atau ditukarkan mengikut bunyi jika sesuai.
  4. Pastikan ejaan Jawi adalah betul dan tepat.

  TEKS ASAL:
  ${text}
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        systemInstruction: "Anda adalah pakar bahasa yang mahir dalam sistem ejaan Jawi Lama dan Baru.",
        temperature: 0.3,
      }
    });

    return response.text || text;
  } catch (error) {
    console.error("Error converting to Jawi:", error);
    throw new Error("Gagal menukar ke Jawi.");
  }
};