import React from 'react';
import { SavedRPH } from '../types';

interface SavedRPHCardProps {
  item: SavedRPH;
  onClick: (item: SavedRPH) => void;
  onDelete: (e: React.MouseEvent, id: string) => void;
}

export const SavedRPHCard: React.FC<SavedRPHCardProps> = ({ item, onClick, onDelete }) => {
  const dateObj = new Date(item.timestamp);
  const dateString = dateObj.toLocaleDateString('ms-MY', { day: 'numeric', month: 'short', year: 'numeric' });
  const timeString = dateObj.toLocaleTimeString('ms-MY', { hour: '2-digit', minute: '2-digit' });

  return (
    <div 
      onClick={() => onClick(item)}
      className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 hover:shadow-md hover:border-indigo-300 transition-all cursor-pointer group relative"
    >
      <div className="flex justify-between items-start mb-3">
        <span className="inline-block px-2 py-1 bg-indigo-50 text-indigo-700 text-xs font-bold rounded uppercase tracking-wide">
          Minggu {item.weekItem.minggu}
        </span>
        <button 
          onClick={(e) => onDelete(e, item.id)}
          className="text-slate-300 hover:text-red-500 transition-colors p-1"
          title="Padam RPH"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
          </svg>
        </button>
      </div>

      <h3 className="font-bold text-slate-800 text-lg mb-1">{item.className}</h3>
      <p className="text-slate-500 text-sm mb-4 flex items-center gap-2">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        {item.day}{item.date ? ` (${item.date})` : ''}, {item.time}
      </p>

      <div className="border-t border-slate-100 pt-3">
        <p className="text-xs text-slate-400 font-medium uppercase mb-1">Topik / Bidang</p>
        <p className="text-slate-700 text-sm line-clamp-2">
          {item.selectedBidang ? (
            <span className="font-semibold text-indigo-600">{item.selectedBidang}: </span>
          ) : null}
          {item.weekItem.topik}
        </p>
      </div>

      <div className="mt-4 flex justify-between items-center text-xs text-slate-400">
        <span>Disimpan: {dateString}</span>
        <span>{timeString}</span>
      </div>
    </div>
  );
};