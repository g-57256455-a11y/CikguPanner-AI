import React, { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';
import { WeeklyPlanItem, DAYS_OF_WEEK, SavedRPH } from '../types';
import { generateDailyRPH, convertToJawi } from '../services/geminiService';
import { Button } from './Button';

interface DailyRPHModalProps {
  isOpen: boolean;
  onClose: () => void;
  weekItem: WeeklyPlanItem | null;
  rptContent: string;
  onSave?: (rphData: Omit<SavedRPH, 'id' | 'timestamp'>) => void;
  initialData?: SavedRPH | null; // If provided, opens in View Mode
}

export const DailyRPHModal: React.FC<DailyRPHModalProps> = ({ 
  isOpen, 
  onClose, 
  weekItem, 
  rptContent,
  onSave,
  initialData
}) => {
  const [selectedDay, setSelectedDay] = useState("Isnin");
  const [date, setDate] = useState("");
  const [className, setClassName] = useState("");
  const [time, setTime] = useState("");
  const [selectedBidang, setSelectedBidang] = useState<string>("");
  const [additionalContext, setAdditionalContext] = useState("");
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedRPH, setGeneratedRPH] = useState<string | null>(null);
  
  // Jawi conversion state
  const [jawiRPH, setJawiRPH] = useState<string | null>(null);
  const [isConvertingJawi, setIsConvertingJawi] = useState(false);
  const [viewMode, setViewMode] = useState<'rumi' | 'jawi'>('rumi');

  useEffect(() => {
    if (isOpen) {
      if (initialData) {
        // View Mode: Load existing data
        setGeneratedRPH(initialData.content);
        setJawiRPH(initialData.jawiContent || null);
        setSelectedDay(initialData.day);
        setDate(initialData.date || "");
        setClassName(initialData.className);
        setTime(initialData.time);
        setSelectedBidang(initialData.selectedBidang || "");
        setViewMode('rumi');
      } else if (weekItem) {
        // Generate Mode: Reset inputs
        setGeneratedRPH(null);
        setJawiRPH(null);
        setViewMode('rumi');
        setIsGenerating(false);
        setIsConvertingJawi(false);
        setAdditionalContext("");
        setDate("");
        // Reset Day to Isnin default or keep previous selection? Resetting is safer.
        setSelectedDay("Isnin");
        
        // Default select the first bidang if available, otherwise empty
        if (weekItem.bidangList && weekItem.bidangList.length > 0) {
          setSelectedBidang(weekItem.bidangList[0]);
        } else {
          setSelectedBidang("");
        }
      }
    }
  }, [isOpen, weekItem, initialData]);

  if (!isOpen || (!weekItem && !initialData)) return null;

  // If initialData is present, use its weekItem, otherwise use the prop weekItem
  const activeWeekItem = initialData ? initialData.weekItem : weekItem!;

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newDate = e.target.value;
    setDate(newDate);
    
    // Auto-detect day from date
    if (newDate) {
      const dateObj = new Date(newDate);
      const dayName = dateObj.toLocaleDateString('ms-MY', { weekday: 'long' });
      // Normalize day name to match our DAYS_OF_WEEK list if possible
      // This helps simple matching. 'Isnin' -> 'Isnin'.
      if (DAYS_OF_WEEK.includes(dayName)) {
        setSelectedDay(dayName);
      } else {
        // If it's Saturday/Sunday or mismatch, we still set it but maybe user wants to change manually
        // Just leave it or set it if you want to support weekend classes
        // For now, let's just use the dayName so it reflects reality
        // But if our UI only supports the 5 buttons, we might need to be careful.
        // The buttons set state, so if state is "Ahad", buttons won't highlight. That's fine.
        setSelectedDay(dayName);
      }
    }
  };

  const handleGenerate = async () => {
    if (!className || !time) {
      alert("Sila isi nama kelas dan masa.");
      return;
    }

    if (activeWeekItem.bidangList && activeWeekItem.bidangList.length > 0 && !selectedBidang) {
       alert("Sila pilih bidang/topik untuk diajar.");
       return;
    }

    setIsGenerating(true);
    // Reset Jawi content when regenerating
    setJawiRPH(null);
    setViewMode('rumi');

    try {
      const result = await generateDailyRPH(rptContent, {
        weekItem: activeWeekItem,
        day: selectedDay,
        date: date || undefined,
        className,
        time,
        selectedBidang: selectedBidang || undefined,
        additionalContext: additionalContext || undefined
      });
      setGeneratedRPH(result);
    } catch (error) {
      alert("Ralat semasa menjana RPH. Sila cuba lagi.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleConvertToJawi = async () => {
    if (!generatedRPH) return;
    
    // If we already have the Jawi version, just switch view
    if (jawiRPH) {
      setViewMode('jawi');
      return;
    }

    setIsConvertingJawi(true);
    try {
      const result = await convertToJawi(generatedRPH);
      setJawiRPH(result);
      setViewMode('jawi');
    } catch (error) {
      alert("Gagal menukar ke tulisan Jawi.");
    } finally {
      setIsConvertingJawi(false);
    }
  };

  const handleCopy = () => {
    const textToCopy = viewMode === 'jawi' ? jawiRPH : generatedRPH;
    if (textToCopy) {
      navigator.clipboard.writeText(textToCopy);
      alert(`RPH (${viewMode === 'jawi' ? 'Jawi' : 'Rumi'}) disalin ke papan keratan!`);
    }
  };

  const handleSave = () => {
    if (onSave && generatedRPH) {
      onSave({
        weekItem: activeWeekItem,
        day: selectedDay,
        date: date || undefined,
        className,
        time,
        content: generatedRPH,
        jawiContent: jawiRPH,
        selectedBidang: selectedBidang || undefined
      });
    }
  };

  const currentContent = viewMode === 'jawi' ? jawiRPH : generatedRPH;
  const isReadOnly = !!initialData; // Mode check

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h2 className="text-2xl font-bold text-slate-800">
                {isReadOnly ? "Lihat RPH" : "Jana RPH"}: Minggu {activeWeekItem.minggu}
              </h2>
              {isReadOnly && (
                <span className="bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded-full font-bold uppercase">
                  Disimpan
                </span>
              )}
            </div>
            <p className="text-slate-500 text-sm">
               {activeWeekItem.tema} - {activeWeekItem.topik}
            </p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {!generatedRPH ? (
            <div className="space-y-6">
              
              {/* Bidang Selection - Show only if list is detected */}
              {activeWeekItem.bidangList && activeWeekItem.bidangList.length > 0 && (
                <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-xl">
                  <label className="block text-sm font-bold text-indigo-900 mb-3">
                    Apa yang anda ingin ajar hari ini?
                  </label>
                  <div className="flex flex-wrap gap-3">
                    {activeWeekItem.bidangList.map((bidang) => (
                      <label key={bidang} className={`cursor-pointer px-4 py-2 rounded-lg text-sm font-medium border transition-all ${
                        selectedBidang === bidang 
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-md ring-2 ring-indigo-200 ring-offset-1'
                          : 'bg-white text-slate-600 border-indigo-200 hover:border-indigo-400 hover:bg-indigo-50'
                      }`}>
                        <input 
                          type="radio" 
                          name="bidang" 
                          value={bidang} 
                          className="sr-only"
                          checked={selectedBidang === bidang}
                          onChange={(e) => setSelectedBidang(e.target.value)}
                        />
                        {bidang}
                      </label>
                    ))}
                  </div>
                  <p className="text-xs text-indigo-600 mt-2">
                    * AI akan menjana objektif dan aktiviti berdasarkan bidang yang dipilih sahaja.
                  </p>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                   <label className="block text-sm font-medium text-slate-700 mb-2">Tarikh</label>
                   <input
                    type="date"
                    value={date}
                    onChange={handleDateChange}
                    className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none mb-4"
                  />

                  <label className="block text-sm font-medium text-slate-700 mb-2">Hari</label>
                  <div className="flex flex-wrap gap-2">
                    {DAYS_OF_WEEK.map((day) => (
                      <button
                        key={day}
                        onClick={() => setSelectedDay(day)}
                        className={`px-3 py-2 rounded-md text-sm border transition-colors ${
                          selectedDay === day 
                            ? 'bg-slate-800 text-white border-slate-800' 
                            : 'bg-white text-slate-600 border-slate-300 hover:border-slate-500'
                        }`}
                      >
                        {day}
                      </button>
                    ))}
                    {!DAYS_OF_WEEK.includes(selectedDay) && selectedDay !== "" && (
                       <button
                        className="px-3 py-2 rounded-md text-sm border bg-slate-800 text-white border-slate-800"
                      >
                        {selectedDay}
                      </button>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Nama Kelas</label>
                  <input
                    type="text"
                    value={className}
                    onChange={(e) => setClassName(e.target.value)}
                    placeholder="Contoh: 5 Bestari"
                    className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Masa</label>
                  <input
                    type="text"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    placeholder="Contoh: 8:00 - 9:00 Pagi"
                    className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                  />
                </div>
              </div>

              {/* Additional Context Input */}
              <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl">
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Tambahan / Catatan Guru <span className="text-slate-400 font-normal">(Pilihan)</span>
                </label>
                <textarea
                  value={additionalContext}
                  onChange={(e) => setAdditionalContext(e.target.value)}
                  placeholder="Contoh: Gunakan peta i-Think, beri fokus kepada murid pemulihan, aktiviti berkumpulan..."
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none resize-none h-24 text-sm"
                ></textarea>
                <p className="text-xs text-slate-500 mt-2">
                   Masukkan sebarang permintaan khas untuk AI pertimbangkan semasa menjana RPH ini.
                </p>
              </div>
            </div>
          ) : (
            <div>
              {/* Header Info Bar in Result Mode */}
              <div className="bg-slate-50 p-4 rounded-xl mb-6 flex flex-wrap gap-4 items-center justify-between border border-slate-200">
                <div className="flex gap-4 text-sm text-slate-700 flex-wrap">
                  <div><span className="font-bold">Kelas:</span> {className}</div>
                  <div><span className="font-bold">Hari:</span> {selectedDay} {date ? `(${date})` : ''}</div>
                  <div><span className="font-bold">Masa:</span> {time}</div>
                  {selectedBidang && <div><span className="font-bold">Bidang:</span> {selectedBidang}</div>}
                </div>
                {!isReadOnly && (
                  <button 
                    onClick={() => setGeneratedRPH(null)}
                    className="text-xs text-indigo-600 hover:underline font-medium"
                  >
                    Edit Maklumat
                  </button>
                )}
              </div>

              {/* Jawi/Rumi Toggle Tabs */}
              <div className="flex items-center justify-end mb-4 border-b border-slate-200">
                <button
                  onClick={() => setViewMode('rumi')}
                  className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                    viewMode === 'rumi'
                      ? 'border-indigo-600 text-indigo-600'
                      : 'border-transparent text-slate-500 hover:text-slate-700'
                  }`}
                >
                  Rumi
                </button>
                <button
                  onClick={handleConvertToJawi}
                  disabled={isConvertingJawi}
                  className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors flex items-center gap-2 ${
                    viewMode === 'jawi'
                      ? 'border-indigo-600 text-indigo-600'
                      : 'border-transparent text-slate-500 hover:text-slate-700'
                  }`}
                >
                  {isConvertingJawi ? 'Menukar...' : 'Jawi'}
                </button>
              </div>

              {/* RPH Content */}
              <div 
                className={`prose prose-indigo max-w-none prose-table:border prose-table:shadow-sm prose-th:bg-indigo-50 prose-th:text-indigo-900 prose-th:p-3 prose-td:p-3 prose-td:border-t prose-td:border-slate-200 prose-img:rounded-xl ${
                  viewMode === 'jawi' ? 'text-right' : 'text-left'
                }`}
                dir={viewMode === 'jawi' ? 'rtl' : 'ltr'}
              >
                {isConvertingJawi ? (
                   <div className="flex flex-col items-center justify-center py-12 text-slate-400">
                     <svg className="animate-spin h-8 w-8 text-indigo-500 mb-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                     </svg>
                     <p>Sedang menukar ke tulisan Jawi...</p>
                   </div>
                ) : (
                  <ReactMarkdown 
                    remarkPlugins={[remarkGfm]} 
                    rehypePlugins={[rehypeRaw]}
                  >
                    {currentContent || ''}
                  </ReactMarkdown>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-slate-100 bg-slate-50 rounded-b-2xl flex flex-wrap justify-end gap-3">
          {!generatedRPH ? (
            <>
              <Button variant="outline" onClick={onClose}>Batal</Button>
              <Button onClick={handleGenerate} isLoading={isGenerating}>
                 {activeWeekItem.bidangList && activeWeekItem.bidangList.length > 0 && selectedBidang
                   ? `Jana RPH (${selectedBidang})` 
                   : 'Jana RPH'}
              </Button>
            </>
          ) : (
            <>
              {!isReadOnly && (
                <Button variant="outline" onClick={() => {
                  setGeneratedRPH(null);
                  setJawiRPH(null);
                  setViewMode('rumi');
                }}>Jana Semula</Button>
              )}
              
              {!isReadOnly && (
                <Button variant="secondary" onClick={handleSave}>
                  Simpan RPH
                </Button>
              )}

              <Button variant="primary" onClick={handleCopy}>
                Salin RPH {viewMode === 'jawi' ? '(Jawi)' : '(Rumi)'}
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};