import React from 'react';
import { WeeklyPlanItem } from '../types';
import { Button } from './Button';

interface WeekCardProps {
  item: WeeklyPlanItem;
  onGenerateRPH: (item: WeeklyPlanItem) => void;
}

export const WeekCard: React.FC<WeekCardProps> = ({ item, onGenerateRPH }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition-shadow duration-300 flex flex-col h-full">
      <div className="bg-slate-50 px-4 py-3 border-b border-slate-100 flex justify-between items-center">
        <h3 className="font-bold text-slate-700 text-lg">Minggu {item.minggu}</h3>
        {item.catatan ? (
          <span className="text-xs font-semibold px-2 py-1 bg-amber-100 text-amber-800 rounded-full truncate max-w-[120px]">
            {item.catatan}
          </span>
        ) : (
          <span className="text-xs font-semibold px-2 py-1 bg-green-100 text-green-800 rounded-full">
            Pembelajaran
          </span>
        )}
      </div>
      
      <div className="p-4 space-y-3 flex-grow">
        <div>
          <p className="text-xs text-slate-500 uppercase tracking-wider font-semibold">Tema</p>
          <p className="text-slate-800 font-medium">{item.tema}</p>
        </div>
        
        <div>
          <p className="text-xs text-slate-500 uppercase tracking-wider font-semibold mb-1">Topik / Bidang</p>
          <p className="text-slate-800 mb-2">{item.topik}</p>
          
          {/* Display Bidang List as Tags */}
          {item.bidangList && item.bidangList.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {item.bidangList.map((bidang, idx) => (
                <span key={idx} className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-100">
                  {bidang}
                </span>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-2 mt-2">
           <div className="bg-slate-50 p-2 rounded text-xs border border-slate-100">
             <span className="block text-indigo-500 font-bold mb-1 uppercase text-[10px]">Standard Kandungan</span>
             <p className="line-clamp-3 text-slate-600">{item.standardKandungan}</p>
           </div>
        </div>
      </div>

      <div className="px-4 py-3 bg-slate-50 border-t border-slate-100 mt-auto">
        <Button 
          variant="secondary" 
          onClick={() => onGenerateRPH(item)}
          className="w-full text-sm"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          Jana RPH Harian
        </Button>
      </div>
    </div>
  );
};